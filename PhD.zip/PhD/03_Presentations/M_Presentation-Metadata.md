2025-05-26

# Presentation Metadata
Record metadata of the presentations you gave. Posters can be recorded following the same scheme. Feel free to adapt the template to your needs. 

---

## TITLE

Date: 

Venue: 

Co-Authors:

Slides: FOLDER or DOI

Feedback: 

---