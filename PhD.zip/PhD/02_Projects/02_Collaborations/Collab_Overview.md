2025-05-26

# Collaboration Overview

Write here a description of your collaboration partners and detail about the contact person.

---


# TEMPLATE / Collaboration Title

## Collaborators
Collaborator.Name:

Collaborator.ORCID:

Collaborator.Email:

...

## Description
Project.Context:

Project.Aims:

Contribution:

## Dates
Project.Start:

Project.End:

MeetingSchedule:

---